# class_notes
this are Radical class notes 
